package net.javaguides.springboot.springsecurity.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import net.javaguides.springboot.springsecurity.model.Employee;

@Repository
public class EmpDaoImpl implements EmpDao {

    private JdbcTemplate template;

    public JdbcTemplate getTemplate() {
        return template;
    }

    public void setTemplate(JdbcTemplate template) {
        this.template = template;
    }

    public List<Employee> getEmployeesByPage(int pageid, int total) {
        String sql= "SELECT * FROM employee "+(pageid-1)+","+total;

        return getTemplate().query(sql, new RowMapper<Employee>() {
            public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
                Employee emp = new Employee();
                emp.setId((long) rs.getInt("id"));
                emp.setFirstName(rs.getString("first_name"));
                emp.setLastName(rs.getString("last_name"));
                emp.setStatus(rs.getString("status"));
                emp.setPosition(rs.getString("position"));

                return emp;
            }
        });
    }
}