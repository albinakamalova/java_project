package net.javaguides.springboot.springsecurity.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.javaguides.springboot.springsecurity.dao.EmpDao;
import net.javaguides.springboot.springsecurity.model.Employee;

@Service
public class EmpServImpl implements EmpServ {

    @Autowired
    private EmpDao edao;

    public List<Employee> getEmployeesByPage(int pageid, int total) {
        return edao.getEmployeesByPage(pageid, total);
    }
}