package net.javaguides.springboot.springsecurity.service;

import java.util.List;

import net.javaguides.springboot.springsecurity.model.Employee;

public interface EmpServ {

    public List<Employee> getEmployeesByPage(int pageid, int total);
}
