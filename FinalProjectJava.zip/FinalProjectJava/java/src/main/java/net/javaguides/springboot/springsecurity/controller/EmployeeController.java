package net.javaguides.springboot.springsecurity.controller;

import net.javaguides.springboot.springsecurity.model.Employee;
import net.javaguides.springboot.springsecurity.repository.EmployeeRepository;
import net.javaguides.springboot.springsecurity.service.EmpServ;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class EmployeeController {

    private EmployeeRepository employeeRepository;

    @Autowired
    public void setEmployeeRepository(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @Autowired
    EmpServ eserv;

    @RequestMapping(value= "/init/{page_id}", method= RequestMethod.GET)
    public ModelAndView paginate(@PathVariable int page_id) {
        int total = 5;
        if(page_id == 1) {
            // do nothing!
        } else {
            page_id= (page_id-1)*total+1;
        }

        List<Employee> list = eserv.getEmployeesByPage(page_id, total);

        return new ModelAndView("welcome", "list", list);
    }

    @RequestMapping(path = "/")
    public String index() {
        return "index";
    }

    @RequestMapping(path = "/employees/add", method = RequestMethod.GET)
    public String createEmployee(Model model) {
        model.addAttribute("employee", new Employee());
        return "edit";
    }

    @RequestMapping(path = "/employees", method = RequestMethod.POST)
    public String saveEmployee(Employee employee) {
        employeeRepository.save(employee);
        return "redirect:/";
    }

    @RequestMapping(path = "/employees", method = RequestMethod.GET)
    public String getAllEmployees(Model model) {
        model.addAttribute("employees", employeeRepository.findAll());
        return "employees";
    }

    /*
    * Sorting
    * By default all the employees are sorted by their first name in ascending order
    * you have 3 employees per page
    * options for the sorting are: id, last name, position and status
    * this method returns template sort.html
    */
    @RequestMapping(path = "/employees/sort", method = RequestMethod.GET)
    public String getEmployeesByName(
            @RequestParam(value = "name", defaultValue = "firstName", required = false) String name,
            @RequestParam(value = "page",  defaultValue = "0", required = false) int page,
            @RequestParam(value = "count", defaultValue = "3", required = false) int count,
            @RequestParam(value = "sort", defaultValue = "asc", required = false) String sort,
            Model model) {

        // PageRequest makes a request to the repository that returns all the
        // elements (employees) then they are sorted by using Sort class (object)
        model.addAttribute("employees", employeeRepository.findAll(
                PageRequest.of(page, count,  Sort.by(sort.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, name))));
        return "sort";
    }


    @RequestMapping(path = "/employees/edit/{id}", method = RequestMethod.GET)
    public String editEmployee(Model model, @PathVariable(value = "id") Long id) {
        model.addAttribute("employee", employeeRepository.findById(id));
        return "edit";
    }

    @RequestMapping(path = "/employees/delete/{id}", method = RequestMethod.GET)
    public String deleteEmployee(@PathVariable(name = "id") Long id) {
        employeeRepository.deleteById(id);
        return "redirect:/employees";
    }
}
