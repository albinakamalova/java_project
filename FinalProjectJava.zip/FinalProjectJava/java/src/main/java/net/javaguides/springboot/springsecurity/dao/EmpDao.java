package net.javaguides.springboot.springsecurity.dao;

import java.util.List;

import net.javaguides.springboot.springsecurity.model.Employee;

public interface EmpDao {

    public List<Employee> getEmployeesByPage(int pageid, int total);
}